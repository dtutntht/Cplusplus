// for data IO
#include <iostream>
// for Sleep function
#include <windows.h>
// for file IO
#include <fstream>
// for file delete
#include <cstdio>
// for mouse control
#include <winuser.h>
#include "Mouse_control.h"
#pragma comment (lib, "User32.lib")


using std::cout ; using std::ofstream ; using std::endl ; using std ::string ; using std::fstream ;
void test ();

class mouse_control mouse;

int main (){

    cout << "hello world" << endl;
    test();
    cout << "DONE!" << endl;
    Sleep(100000000);

}


void mouse_control::record_pixel(int test_item){
    string log_name("tmp.txt");
    fstream logger;
    logger.open(log_name, std::ios_base::app);
    if (! logger.is_open()) {
        cout << "Failed to open output file : " << log_name << endl;
    } else {
        logger << "Test_item_" << test_item << " : x = " << cur_pixel_x << ", y = " << cur_pixel_y << endl;
    }
    logger.close();

}

void mouse_control::move(direction direct, int pixel){
    
    switch(direct){
        case direction::left:
        cur_pixel_x -= pixel;
        break;
        case direction::right:
        cur_pixel_x += pixel;
        break;
        case direction::up:
        cur_pixel_y -= pixel;
        break;
        case direction::down:
        cur_pixel_y += pixel;
        break;
        case direction::init:
        cout << start_pixel_line1[0];
        cout << start_pixel_line1[1];
        cur_pixel_x = start_pixel_line1[0];
        cur_pixel_y = start_pixel_line1[1];
        break;
    }
    
    SetCursorPos(cur_pixel_x,cur_pixel_y);
    
}

void  mouse_control::left_click(){
    mouse_event(MOUSEEVENTF_RIGHTDOWN | MOUSEEVENTF_RIGHTUP,0,0,0,0);
    //mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP,0,0,0,0);
}

void test (){
    
    int test_total = 23;
    int test_line_array[10];
    int test_per_line = 5;
    int test_full_line = test_total / test_per_line;
    int test_modulus = test_total % test_per_line;
    //distribute the test count to per line of GUI tool.
    int i;
    for (i=0;i<test_full_line;i++) {
        test_line_array[i] = 5;
    }
    test_line_array[test_full_line] = test_modulus;

    mouse.move(direction::init,0);

    int test_cnt;
    for (i=0;i<=test_full_line;i++) {

        for (test_cnt=1;test_cnt<=test_line_array[i];test_cnt++) {
            mouse.left_click();
            mouse.move(direction::down,10);
            mouse.record_pixel(test_cnt);
            Sleep(500);
        }
        cout << "Loop : " << i << "Complete" << endl;
        mouse.move(direction::up,50);
        mouse.move(direction::right,10);
        
    }
}

